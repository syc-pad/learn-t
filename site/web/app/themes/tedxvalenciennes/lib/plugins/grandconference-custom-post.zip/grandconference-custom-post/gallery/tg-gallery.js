jQuery(function($){
    $('#wpsimplegallery a').colorbox({
        maxWidth: '85%',
        maxHeight: '85%'
    });
});